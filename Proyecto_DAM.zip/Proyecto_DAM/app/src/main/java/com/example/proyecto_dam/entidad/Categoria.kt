package com.example.proyecto_dam.entidad

class Categoria(
    codigo:Int,
    nombre:String
) {
}