package com.example.proyecto_dam

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.Toast
import com.example.proyecto_dam.controlador.ArregloUsuario
import com.example.proyecto_dam.entidad.Usuario
import com.google.android.material.textfield.TextInputEditText

private lateinit var txtNombreR:TextInputEditText
private lateinit var txtApelldoR:TextInputEditText
private lateinit var rbtMasculino:RadioButton
private lateinit var rbtFemenino:RadioButton
private lateinit var txtUsuarioR:TextInputEditText
private lateinit var txtContrasenaR:TextInputEditText
private lateinit var btnRegistrarR:Button
private lateinit var btnVolverR:Button


class UsuarioActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registrar_usuario)

        txtNombreR = findViewById(R.id.txtNombre)
        txtApelldoR = findViewById(R.id.txtApellido)
        rbtMasculino = findViewById(R.id.rbtMasculino)
        rbtFemenino = findViewById(R.id.rbtFemenino)
        txtUsuarioR = findViewById(R.id.txtUsuarioR)
        txtContrasenaR = findViewById(R.id.txtContrasenaR)
        btnRegistrarR = findViewById(R.id.btnRegistrarR)
        btnVolverR = findViewById(R.id.btnVolverR)

        //
        btnRegistrarR.setOnClickListener{Registrar()}
        btnVolverR.setOnClickListener{Volver()}
    }


    fun  Registrar(){
            var nom =""; var ape =""; var gen=""
            var usu = ""; var con = "";

        nom = txtNombreR.text.toString()
        ape = txtApelldoR.text.toString()
        usu = txtUsuarioR.text.toString()
        con = txtContrasenaR.text.toString()

        if (rbtMasculino.isChecked()){
            gen = "Masculino"
        }else if(rbtFemenino.isChecked()){
            gen = "Femenino"
        }

        var usua = Usuario(0 , nom, ape,gen, usu, con)

        var estado = ArregloUsuario().Registrar(usua)

        if (estado>0)
            Toast.makeText(this,"Usuario registrado", Toast.LENGTH_LONG).show()
        else
            Toast.makeText(this,"Error en el registro", Toast.LENGTH_LONG).show()
    }

    fun Volver(){

    }


}