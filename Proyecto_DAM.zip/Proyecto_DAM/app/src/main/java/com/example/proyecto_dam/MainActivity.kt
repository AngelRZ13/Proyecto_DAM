package com.example.proyecto_dam

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proyecto_dam.adaptador.ComidaAdapter
import com.example.proyecto_dam.base.BurgerBD
import com.example.proyecto_dam.controlador.ArregloComida
import com.example.proyecto_dam.utils.appConfig

class MainActivity : AppCompatActivity() {
    private lateinit var rvBurger:RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rvBurger = findViewById(R.id.rvPizzaMenuTopMenu)

        var datos=ArregloComida().listado()

        var adaptador=ComidaAdapter(datos)

        rvBurger.layoutManager=LinearLayoutManager(this,RecyclerView.HORIZONTAL,false)
        rvBurger.adapter=adaptador
    }






}