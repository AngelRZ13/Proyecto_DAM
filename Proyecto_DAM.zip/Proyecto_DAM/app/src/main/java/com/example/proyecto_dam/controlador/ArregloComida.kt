package com.example.proyecto_dam.controlador

import android.database.sqlite.SQLiteDatabase
import com.example.proyecto_dam.entidad.Comida
import com.example.proyecto_dam.utils.appConfig

class ArregloComida {

    fun listado():ArrayList<Comida>{
        var data = ArrayList<Comida>()
        var cn:SQLiteDatabase=appConfig.BD.readableDatabase

        var SQL="select * from tb_comida"
        var rs = cn.rawQuery(SQL, null)

        while (rs.moveToNext()){
            var bean = Comida(
                rs.getInt(0),
                rs.getString(1),
                rs.getDouble(2),
                rs.getString(3),
                rs.getString(4))

            data.add(bean)
        }
        return data

    }

}