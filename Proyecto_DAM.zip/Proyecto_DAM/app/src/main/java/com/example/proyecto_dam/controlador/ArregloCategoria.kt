package com.example.proyecto_dam.controlador

import android.database.sqlite.SQLiteDatabase
import com.example.proyecto_dam.utils.appConfig

class ArregloCategoria {
    fun listadoCategoria():ArrayList<String>{
        var data=ArrayList<String>()
        var cn : SQLiteDatabase = appConfig.BD.readableDatabase
        var SQL = "select * from tb_distrito"
        var rs = cn.rawQuery(SQL,null)
        while (rs.moveToNext()){

            var bean =rs.getString(1)
            data.add(bean)
        }
        return data
    }

}