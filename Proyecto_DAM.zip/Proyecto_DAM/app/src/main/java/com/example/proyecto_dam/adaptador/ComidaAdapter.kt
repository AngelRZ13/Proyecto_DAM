package com.example.proyecto_dam.adaptador


import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.proyecto_dam.R
import com.example.proyecto_dam.entidad.Comida
import com.example.proyecto_dam.utils.appConfig

class ComidaAdapter(var data:ArrayList<Comida>):RecyclerView.Adapter<ViewComida>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewComida {

        var vista=LayoutInflater.from(parent.context).inflate(R.layout.menu_item,parent,false)
        return ViewComida(vista)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: ViewComida, position: Int) {
        holder.tvNombre.text=data.get(position).nombre
        holder.tvCategoria.text=data.get(position).Categoria
        holder.tvPrecio.text =data.get(position).precio.toString()

        var contexto : Context=holder.itemView.context

        var IMG=1
        IMG=contexto.resources.getIdentifier(data.get(position).foto,"drawable",contexto.packageName)
        holder.imgFoto.setImageResource(IMG)

        holder.itemView.setOnClickListener{
            var intent=Intent(appConfig.CONTEXT,null)
            intent.putExtra("comida",data.get(position))
            ContextCompat.startActivity(appConfig.CONTEXT,intent,null)
        }

    }


}