package com.example.proyecto_dam

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class LoginActivity : AppCompatActivity() {
    private lateinit var txtUsuarioL: TextInputEditText
    private lateinit var txtContrasenaL: TextInputEditText
    private lateinit var btnIngresar: Button
    private lateinit var btnRegistrar: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_usuario)

        txtUsuarioL = findViewById(R.id.txtUsuario)
        txtContrasenaL = findViewById(R.id.txtContrasena)
        btnIngresar = findViewById(R.id.btnIngresar)
        btnRegistrar = findViewById(R.id.btnRegistrar)
        //
        btnIngresar.setOnClickListener{Ingresar()}
        btnRegistrar.setOnClickListener{Registrar()}
    }

    fun Ingresar(){
        var usu="" ;var con=""

        usu = txtUsuarioL.text.toString()
        con = txtContrasenaL.text.toString()





    }

    fun  Registrar(){

    }




}