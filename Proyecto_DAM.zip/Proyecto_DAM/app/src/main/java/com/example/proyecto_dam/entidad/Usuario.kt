package com.example.proyecto_dam.entidad

import java.io.Serializable

class Usuario (
    var codigo:Int,
    var nombre:String, var apellido:String,var genero:String,
    var usuario:String, var contrasena:String,

):Serializable{
}