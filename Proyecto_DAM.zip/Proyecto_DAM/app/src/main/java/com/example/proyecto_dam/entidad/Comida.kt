package com.example.proyecto_dam.entidad

import java.io.Serializable

class Comida (

    var codigo:Int, var nombre:String,
    var precio: Double,
    var foto:String, var Categoria:String
    ):Serializable{
}